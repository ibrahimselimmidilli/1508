﻿using _1647_StokTakip_Uygulamalar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1647_StokTakip_Uygulamalar.Model
{
    public class musteri
    {

        [Key]

        public int Id { get; set; }

        public string MusteriAdi { get; set; }

        public virtual ICollection<Urun>Urunler { get; set; } = new HashSet<Urun>();

    }
}
